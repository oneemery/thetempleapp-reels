# 3D felt dolls for the Temple cast, modelled after the reference sheet. Used inside full3d.py / lineup.py
# (needs felt(), emit(), gold(), sc from the temple3d header).
import bpy, bmesh, math, random as _rnd
from mathutils import Vector

def L(c): return tuple(x ** 2.2 for x in c)  # sRGB -> linear

SKIN = L((0.68, 0.4, 0.24)); SKIN_LIGHT = L((0.76, 0.47, 0.3))
THREAD = L((0.95, 0.86, 0.62)); SANDAL = L((0.48, 0.27, 0.15)); BELT = L((0.5, 0.3, 0.17)); ROPE = L((0.86, 0.76, 0.56))
CAST = {
    'paul':  dict(skin=SKIN_LIGHT, robe=L((0.46, 0.23, 0.15)), cloak=L((0.88, 0.77, 0.63)), hair='sides', hair_col=L((0.56, 0.54, 0.51)),
                  beard='long', beard_col=L((0.5, 0.49, 0.47)), brows=L((0.4, 0.38, 0.36)), belt='band', prop='scroll'),
    'dking': dict(skin=SKIN, robe=L((0.17, 0.22, 0.52)), cloak=L((0.86, 0.6, 0.2)), hair='curly', hair_col=L((0.07, 0.05, 0.04)),
                  beard='full', beard_col=L((0.07, 0.05, 0.04)), crown=True, belt='buckle'),
    'jesse': dict(skin=SKIN, robe=L((0.45, 0.25, 0.17)), cloak=L((0.48, 0.56, 0.32)), hair='headcloth', hair_col=L((0.9, 0.85, 0.72)),
                  beard='long', beard_col=L((0.97, 0.96, 0.93)), brows=L((0.97, 0.96, 0.93)), belt='band'),
    'p3':    dict(skin=SKIN, robe=L((0.44, 0.22, 0.42)), cloak=None, hair='curly', hair_col=L((0.3, 0.17, 0.11)),
                  beard='trim', beard_col=L((0.3, 0.17, 0.11)), belt='rope'),
    'p2':    dict(skin=SKIN, robe=L((0.36, 0.45, 0.22)), cloak=None, hair='curly', hair_col=L((0.07, 0.05, 0.04)), beard=None, belt='band'),
}
CROWD = [L(c) for c in ((0.2, 0.35, 0.65), (0.82, 0.45, 0.18), (0.3, 0.55, 0.3), (0.5, 0.25, 0.5), (0.3, 0.3, 0.68), (0.85, 0.65, 0.2), (0.2, 0.42, 0.7))]
_mats = {}

def M(name, col, **kw):
    key = (name, col, tuple(sorted(kw.items())))
    if key not in _mats:
        m = felt(name, col, **{k: v for k, v in kw.items() if k != 'sheen'}); b = m.node_tree.nodes['Principled BSDF']
        b.inputs['Sheen Weight'].default_value = kw.get('sheen', 1.0); b.inputs['Sheen Roughness'].default_value = 0.45
        _mats[key] = m
    return _mats[key]

def wool(name, col, curl=45.0, sheen=1.0):
    """Felted wool: base felt plus a curly voronoi relief so beards and hair read as fibre, not clay."""
    key = ('wool', name, col)
    if key in _mats: return _mats[key]
    m = felt(name, col, bump=1.0, scale=260); nt = m.node_tree; b = nt.nodes['Principled BSDF']
    b.inputs['Sheen Weight'].default_value = sheen; b.inputs['Sheen Roughness'].default_value = 0.35
    bp = [n for n in nt.nodes if n.type == 'BUMP'][0]; old = bp.inputs['Height'].links[0].from_socket
    vo = nt.nodes.new('ShaderNodeTexVoronoi'); vo.inputs['Scale'].default_value = curl; vo.feature = 'SMOOTH_F1'
    nz = nt.nodes.new('ShaderNodeTexNoise'); nz.inputs['Scale'].default_value = 900; nz.inputs['Detail'].default_value = 8
    a1 = nt.nodes.new('ShaderNodeMath'); a1.operation = 'MULTIPLY_ADD'; a1.inputs[1].default_value = 0.6
    nt.links.new(vo.outputs['Distance'], a1.inputs[0]); nt.links.new(old, a1.inputs[2])
    a2 = nt.nodes.new('ShaderNodeMath'); a2.operation = 'MULTIPLY_ADD'; a2.inputs[1].default_value = 0.35
    nt.links.new(nz.outputs['Fac'], a2.inputs[0]); nt.links.new(a1.outputs['Value'], a2.inputs[2])
    nt.links.new(a2.outputs['Value'], bp.inputs['Height']); bp.inputs['Strength'].default_value = 0.9; bp.inputs['Distance'].default_value = 0.03
    _mats[key] = m; return m

def _link(o, parent, mat=None, smooth=True):
    if smooth and o.type == 'MESH':
        for p in o.data.polygons: p.use_smooth = True
    if mat: o.data.materials.append(mat)
    bpy.context.view_layer.update()
    o.parent = parent; o.matrix_parent_inverse = parent.matrix_world.inverted()
    return o

def _empty(name, loc, parent=None):
    e = bpy.data.objects.new(name, None); sc.collection.objects.link(e)
    e.location = loc; bpy.context.view_layer.update()
    if parent:
        mw = e.matrix_world.copy(); e.parent = parent; e.matrix_parent_inverse = parent.matrix_world.inverted(); e.matrix_world = mw
    bpy.context.view_layer.update(); return e

def _sphere(loc, r, scale, parent, mat, seg=32):
    bpy.ops.mesh.primitive_uv_sphere_add(segments=seg, ring_count=max(8, seg // 2), radius=r, location=loc)
    o = bpy.context.object; o.scale = scale; return _link(o, parent, mat)

def _shell(name, r_bot, r_top, z0, z1, sy, parent, mat, open_front=None, thick=0.025):
    """A-line robe/cloak: tapered elliptic tube with rounded shoulders, optionally opened at the front (half widths bottom, top)."""
    bpy.ops.mesh.primitive_cylinder_add(vertices=72, radius=1, depth=1, location=(0, 0, 0), end_fill_type='NOTHING')
    o = bpy.context.object; me = o.data
    bm = bmesh.new(); bm.from_mesh(me)
    bmesh.ops.subdivide_edges(bm, edges=[e for e in bm.edges if abs(e.verts[0].co.z - e.verts[1].co.z) > 0.5], cuts=12)
    for v in bm.verts:
        u = v.co.z + 0.5
        r = r_bot + (r_top - r_bot) * (u ** 0.85)
        if u > 0.82: r *= 1 - 0.45 * ((u - 0.82) / 0.18) ** 2
        ang = math.atan2(v.co.y, v.co.x); r *= 1 + 0.025 * (1 - u) ** 1.5 * math.sin(ang * 9)
        v.co.x *= r; v.co.y *= r * sy; v.co.z = z0 + (z1 - z0) * u
    if open_front:
        wb, wt = open_front
        kill = [f for f in bm.faces if f.calc_center_median().y < 0 and abs(f.calc_center_median().x) < wb + (wt - wb) * (f.calc_center_median().z - z0) / (z1 - z0)]
        bmesh.ops.delete(bm, geom=kill, context='FACES')
    bm.to_mesh(me); bm.free()
    so = o.modifiers.new('s', 'SOLIDIFY'); so.thickness = thick; so.offset = 1
    sd = o.modifiers.new('sub', 'SUBSURF'); sd.levels = 1; sd.render_levels = 2
    o.name = name; return _link(o, parent, mat)

def _stitches(name, pts, parent, mat, every=0.045):
    bpy.ops.mesh.primitive_cylinder_add(vertices=8, radius=0.0065, depth=0.026, location=(0, 0, -50)); base = bpy.context.object; base.data.materials.append(mat)
    acc = 0.0
    for a, b in zip(pts[:-1], pts[1:]):
        a, b = Vector(a), Vector(b); seg = (b - a); ln = seg.length
        if ln < 1e-6: continue
        while acc < ln:
            p = a + seg * (acc / ln); o = base.copy(); sc.collection.objects.link(o)
            o.location = p; o.rotation_euler = seg.to_track_quat('Z', 'Y').to_euler(); _link(o, parent, None, smooth=False)
            acc += every
        acc -= ln
    bpy.data.objects.remove(base)

def _curve(name, pts, bevel, parent, mat):
    cu = bpy.data.curves.new(name, 'CURVE'); cu.dimensions = '3D'; cu.bevel_depth = bevel; cu.bevel_resolution = 3
    sp = cu.splines.new('BEZIER'); sp.bezier_points.add(len(pts) - 1)
    for p, c in zip(sp.bezier_points, pts): p.co = c; p.handle_left_type = p.handle_right_type = 'AUTO'
    o = bpy.data.objects.new(name, cu); sc.collection.objects.link(o); o.data.materials.append(mat)
    return _link(o, parent, None, smooth=False)

_mb_n = [0]
def _clump(center, radius, n, rmin, rmax, parent, mat, seed, keep=None, fill=0.75, k=1.4, fuzz=0.012):
    """Fluffy wool mass: metaball blobs scattered on and inside a sphere, merged into one soft shape."""
    rr = _rnd.Random(seed); c = Vector(center); made = 0; tries = 0
    _mb_n[0] += 1; mb = bpy.data.metaballs.new(f'wool{_mb_n[0]}'); mb.resolution = 0.03; mb.render_resolution = 0.012; mb.threshold = 0.6
    while made < n and tries < n * 6:
        tries += 1
        d = Vector((rr.gauss(0, 1), rr.gauss(0, 1), rr.gauss(0, 1))).normalized()
        if keep and not keep(d): continue
        el = mb.elements.new(); el.co = c + d * radius * rr.uniform(fill, 1.0); el.radius = rr.uniform(rmin, rmax) * k; el.stiffness = 2.0; made += 1
    o = bpy.data.objects.new(f'wool{_mb_n[0]}', mb); sc.collection.objects.link(o); o.data.materials.append(mat)
    # real fibre: convert the blob to a mesh and grow short felted fuzz on it
    bpy.ops.object.select_all(action='DESELECT'); o.select_set(True); bpy.context.view_layer.objects.active = o
    bpy.ops.object.convert(target='MESH'); o = bpy.context.object
    ps = o.modifiers.new('fuzz', 'PARTICLE_SYSTEM').particle_system; st = ps.settings
    st.type = 'HAIR'; st.count = 3500; st.use_advanced_hair = True
    st.child_type = 'INTERPOLATED'; st.child_percent = 8; st.rendered_child_count = 8; st.child_length = 0.85
    st.kink = 'CURL'; st.kink_amplitude = fuzz * 0.4; st.kink_frequency = 2; st.roughness_2 = fuzz; st.roughness_endpoint = fuzz * 0.6
    st.root_radius = 0.003; st.tip_radius = 0.0012; st.radius_scale = 1.0; st.material = 1
    st.normal_factor = fuzz; st.factor_random = fuzz * 0.3
    return _link(o, parent, None, smooth=True)

def _front_y(r_bot, r_top, z0, z1, sy, x, z):
    u = max(0, min(1, (z - z0) / (z1 - z0))); r = r_bot + (r_top - r_bot) * u ** 0.85
    if u > 0.82: r *= 1 - 0.45 * ((u - 0.82) / 0.18) ** 2
    return -r * sy * math.sqrt(max(0.0, 1 - (x / r) ** 2))

def doll(kind, loc, rot_z=0.0, scale=1.0, robe=None, name=None, seed=0):
    c = dict(CAST.get(kind, CAST['p2']))
    if robe: c['robe'] = robe
    name = name or kind
    root = _empty(name, (0, 0, 0))
    body = _empty(name + '_body', (0, 0, 0), root)
    sy = 0.62; z_hem, z_sh = 0.1, 1.42
    skin = M('skin' + name, c['skin'], bump=0.4, scale=160)
    thread = M('thread', THREAD, bump=0.1, sheen=0.5)
    robe_m = M('robe' + name, c['robe'], bump=0.6, scale=150)
    _shell(name + '_robe', 0.37, 0.27, z_hem, z_sh, sy, body, robe_m, thick=0.02)
    if c.get('cloak'):
        cl_m = M('cloak' + name, c['cloak'], bump=0.6, scale=150)
        rb_, rt_, csy = 0.40, 0.29, sy * 1.05
        _shell(name + '_cloak', rb_, rt_, z_hem + 0.02, z_sh + 0.02, csy, body, cl_m, open_front=(0.15, 0.06), thick=0.035)
        for sx in (-1, 1):
            pts = []
            for i in range(21):
                u = i / 20; z = z_hem + 0.06 + (z_sh - z_hem - 0.2) * u; x = sx * (0.15 + (0.06 - 0.15) * (z - z_hem) / (z_sh - z_hem) + 0.03)
                pts.append((x, _front_y(rb_, rt_, z_hem + 0.02, z_sh + 0.02, csy, x, z) - 0.04, z))
            _stitches(name + '_st', pts, body, thread)
        pts = [(math.cos(a) * 0.405, math.sin(a) * 0.405 * csy - 0.035, z_hem + 0.07) for a in [math.pi + 0.45 + i * (math.pi - 0.9) / 30 for i in range(31)]]
        _stitches(name + '_hem', pts, body, thread)
    else:
        pts = [(math.cos(a) * 0.375, math.sin(a) * 0.375 * sy - 0.025, z_hem + 0.06) for a in [math.pi + 0.15 + i * (math.pi - 0.3) / 30 for i in range(31)]]
        _stitches(name + '_hem', pts, body, thread)
    cl_or_robe = M('cloak' + name, c['cloak'], bump=0.6, scale=150) if c.get('cloak') else robe_m
    bpy.ops.mesh.primitive_torus_add(major_radius=0.13, minor_radius=0.04, location=(0, 0, z_sh - 0.01)); col = bpy.context.object; col.scale = (1, 0.85, 1)
    _link(col, body, cl_or_robe)
    # belt
    zb = 0.88
    rb = (0.37 + (0.27 - 0.37) * ((zb - z_hem) / (z_sh - z_hem)) ** 0.85) + 0.014
    if c.get('belt') in ('band', 'buckle'):
        bpy.ops.mesh.primitive_cylinder_add(vertices=72, radius=1, depth=0.08, location=(0, 0, zb), end_fill_type='NOTHING')
        bt = bpy.context.object; bt.scale = (rb, rb * sy, 1); so = bt.modifiers.new('s', 'SOLIDIFY'); so.thickness = 0.02
        if c.get('cloak'):
            bm = bmesh.new(); bm.from_mesh(bt.data)
            bmesh.ops.delete(bm, geom=[f for f in bm.faces if not (f.calc_center_median().y < 0 and abs(f.calc_center_median().x) * rb < 0.17)], context='FACES'); bm.to_mesh(bt.data); bm.free()
        _link(bt, body, M('belt', BELT, bump=0.3))
        if c['belt'] == 'buckle':
            bpy.ops.mesh.primitive_torus_add(major_radius=0.045, minor_radius=0.011, location=(0, -rb * sy - 0.02, zb)); bk = bpy.context.object
            bk.rotation_euler.x = math.radians(90); bk.scale = (1.1, 0.9, 1); _link(bk, body, gold('buckle', 0.2))
    elif c.get('belt') == 'rope':
        rm = M('rope', ROPE, bump=0.6, scale=150)
        bpy.ops.mesh.primitive_torus_add(major_radius=1, minor_radius=0.024 / rb, location=(0, 0, zb)); rp = bpy.context.object; rp.scale = (rb, rb * sy, rb)
        _link(rp, body, rm)
        for dx, ln in ((-0.03, 0.32), (0.035, 0.27)):
            _curve(name + '_ropeend', [(dx, -rb * sy - 0.02, zb - 0.01), (dx * 1.6, -rb * sy - 0.04, zb - ln * 0.5), (dx, -rb * sy - 0.035, zb - ln)], 0.017, body, rm)
            _sphere((dx, -rb * sy - 0.035, zb - ln - 0.025), 0.03, (1, 1, 1.3), body, rm, 12)
    # sandals + toes
    for sx in (-1, 1):
        bpy.ops.mesh.primitive_cube_add(location=(sx * 0.13, -0.2, 0.025)); so_ = bpy.context.object; so_.scale = (0.085, 0.14, 0.025)
        bv = so_.modifiers.new('b', 'BEVEL'); bv.width = 0.03; bv.segments = 4
        _link(so_, body, M('sandal', SANDAL, bump=0.3), smooth=False)
        _sphere((sx * 0.13, -0.25, 0.075), 0.075, (1, 1.1, 0.55), body, skin)
        bpy.ops.mesh.primitive_torus_add(major_radius=0.078, minor_radius=0.016, location=(sx * 0.13, -0.27, 0.075)); st = bpy.context.object
        st.rotation_euler.y = math.radians(90); st.scale = (1, 1.15, 0.75); _link(st, body, M('sandal', SANDAL, bump=0.3))
    # head
    head = _empty(name + '_head', (0, 0, 1.5), body)
    hz = 1.75
    _sphere((0, 0, hz), 0.31, (1, 0.93, 1.06), head, skin, 48)
    bpy.ops.mesh.primitive_cylinder_add(vertices=24, radius=0.09, depth=0.2, location=(0, 0, 1.48)); _link(bpy.context.object, head, skin)
    for sx in (-1, 1): _sphere((sx * 0.295, 0.02, hz - 0.02), 0.07, (0.55, 0.75, 1), head, skin)
    bead = bpy.data.materials.get('bead')
    if not bead:
        bead = bpy.data.materials.new('bead'); bead.use_nodes = True; bb = bead.node_tree.nodes['Principled BSDF']
        bb.inputs['Base Color'].default_value = (0.005, 0.004, 0.004, 1); bb.inputs['Roughness'].default_value = 0.12; bb.inputs['Coat Weight'].default_value = 1.0
    eyes = []
    for sx in (-1, 1):
        e = _empty(f'{name}_eye{sx}', (sx * 0.105, -0.268, hz + 0.02), head)
        _sphere((sx * 0.105, -0.268, hz + 0.02), 0.032, (1, 0.8, 1.1), e, bead, 24)
        eyes.append(e)
    bcol = c.get('brows', c['hair_col'] if c['hair'] == 'curly' else L((0.07, 0.05, 0.04)))
    brows = []
    for sx in (-1, 1):
        bp = _empty(f'{name}_browp{sx}', (sx * 0.105, -0.285, hz + 0.115), head)
        _curve(f'{name}_brow{sx}', [(sx * 0.05, -0.282, hz + 0.105), (sx * 0.105, -0.292, hz + 0.125), (sx * 0.16, -0.274, hz + 0.105)], 0.016, bp, M('brow' + name, bcol, bump=0.3))
        brows.append(bp)
    for sx in (-1, 1): _sphere((sx * 0.17, -0.235, hz - 0.06), 0.055, (1, 0.45, 0.75), head, M('cheek', L((0.85, 0.48, 0.45)), bump=0.1))
    _sphere((0, -0.29, hz - 0.025), 0.035, (1.15, 0.8, 0.95), head, skin)
    mouth_m = M('mouth', L((0.55, 0.16, 0.14)), bump=0.0, sheen=0.2)
    my = {'full': -0.345, 'trim': -0.335, 'long': -0.305}.get(c.get('beard'), -0.283)
    mz = hz - (0.03 if c.get('beard') in ('full', 'trim') else 0)
    m_happy = _curve(name + '_smile', [(-0.06, my, mz - 0.1), (0, my - 0.008, mz - 0.13), (0.06, my, mz - 0.1)], 0.013, head, mouth_m)
    m_worry = _curve(name + '_worry', [(-0.055, my, mz - 0.125), (0, my - 0.008, mz - 0.105), (0.055, my, mz - 0.125)], 0.013, head, mouth_m)
    m_worry.hide_render = True
    hc = wool('hair' + name, c['hair_col'], curl=38, sheen=0.5 if max(c['hair_col']) < 0.1 else 1.0)
    if c['hair'] == 'curly':
        _clump((0, 0.03, hz + 0.05), 0.3, 170, 0.05, 0.068, head, hc, seed + 3, keep=lambda d: not (d.y < -0.3 and d.z < 0.62), fill=0.92, k=1.3, fuzz=0.008)
    elif c['hair'] == 'sides':
        for sx in (-1, 1): _clump((sx * 0.25, 0.08, hz + 0.02), 0.09, 30, 0.04, 0.06, head, hc, seed + sx + 5, fuzz=0.014)
    elif c['hair'] == 'headcloth':
        cm = M('cloth' + name, c['hair_col'], bump=0.4, scale=420)
        bpy.ops.mesh.primitive_uv_sphere_add(segments=48, ring_count=24, radius=0.335, location=(0, 0.03, hz + 0.02)); hd = bpy.context.object
        bm = bmesh.new(); bm.from_mesh(hd.data)
        for v in bm.verts:
            if v.co.z < -0.05: v.co.z = -0.05 + (v.co.z + 0.05) * 3.0; v.co.x *= 1.18; v.co.y *= 1.05
        bmesh.ops.delete(bm, geom=[f for f in bm.faces if f.calc_center_median().y < -0.1 and f.calc_center_median().z < 0.2], context='FACES')
        bm.to_mesh(hd.data); bm.free(); so = hd.modifiers.new('s', 'SOLIDIFY'); so.thickness = 0.025
        _link(hd, head, cm)
        bpy.ops.mesh.primitive_torus_add(major_radius=0.3, minor_radius=0.03, location=(0, 0.03, hz + 0.12)); bd = bpy.context.object; bd.scale = (1.06, 1.04, 1)
        _link(bd, head, M('band', L((0.55, 0.32, 0.17)), bump=0.3))
    bcl = c.get('beard_col', (0, 0, 0))
    bc = wool('beard' + name, bcl, curl=55, sheen=0.5 if max(bcl) < 0.1 else 1.0)
    if c.get('beard') == 'long':
        _clump((0, -0.18, hz - 0.31), 0.15, 110, 0.042, 0.06, head, bc, seed + 11, keep=lambda d: d.y < 0.3 and d.z < 0.35, fill=0.85, k=1.4, fuzz=0.016)
        _clump((0, -0.2, hz - 0.47), 0.1, 60, 0.038, 0.054, head, bc, seed + 12, keep=lambda d: d.y < 0.4, fill=0.85, k=1.4, fuzz=0.016)
        _clump((0, -0.2, hz - 0.59), 0.05, 20, 0.03, 0.042, head, bc, seed + 13, k=1.4, fuzz=0.014)
        for sx in (-1, 1): _clump((sx * 0.058, -0.288, hz - 0.085), 0.018, 8, 0.016, 0.022, head, bc, seed + 40 + sx, k=1.4, fuzz=0.008)
    elif c.get('beard') in ('full', 'trim'):
        _clump((0, -0.08, hz - 0.2), 0.21 if c['beard'] == 'full' else 0.195, 150 if c['beard'] == 'full' else 110, 0.04, 0.056, head, bc, seed + 21, keep=lambda d: d.y < 0.0 and d.z < 0.2, fill=0.9, k=1.35, fuzz=0.012)
    if c.get("crown"):
        g = gold('crown', 0.6)
        bpy.ops.mesh.primitive_cylinder_add(vertices=64, radius=0.25, depth=0.12, location=(0, 0.02, hz + 0.25), end_fill_type='NOTHING')
        cr = bpy.context.object; so = cr.modifiers.new('s', 'SOLIDIFY'); so.thickness = 0.025; _link(cr, head, g)
        for i in range(7):
            a = 2 * math.pi * i / 7 - math.pi / 2
            bpy.ops.mesh.primitive_cone_add(vertices=4, radius1=0.06, depth=0.11, location=(0.25 * math.cos(a), 0.02 + 0.25 * math.sin(a), hz + 0.36))
            sp = bpy.context.object; sp.rotation_euler.z = a; sp.scale = (1, 0.3, 1); _link(sp, head, g)
            _sphere((0.262 * math.cos(a), 0.02 + 0.262 * math.sin(a), hz + 0.25), 0.026, (1, 1, 1), head, M('ruby', L((0.65, 0.05, 0.08)), bump=0.0, sheen=0.2), 16)
    # arms
    arms = []
    for sx in (-1, 1):
        pv = _empty(f'{name}_arm{sx}', (sx * 0.25, 0, 1.25), body)
        _sphere((sx * 0.25, 0, 1.25), 0.085, (1, 0.85, 0.9), pv, cl_or_robe)
        bpy.ops.mesh.primitive_cone_add(vertices=32, radius1=0.125, radius2=0.075, depth=0.48, location=(sx * 0.28, 0, 1.25 - 0.25), end_fill_type='NOTHING')
        sl = bpy.context.object; sl.rotation_euler.y = -sx * math.radians(4); so = sl.modifiers.new('s', 'SOLIDIFY'); so.thickness = 0.02
        _link(sl, pv, cl_or_robe)
        _stitches(name + '_cuff', [(sx * 0.3 + math.cos(a) * 0.12, math.sin(a) * 0.12, 1.25 - 0.48) for a in [i * 2 * math.pi / 24 for i in range(25)]], pv, thread, every=0.04)
        _sphere((sx * 0.3, -0.01, 1.25 - 0.56), 0.078, (0.85, 0.7, 1.15), pv, skin)
        _sphere((sx * 0.3 - sx * 0.047, -0.05, 1.25 - 0.53), 0.033, (1, 1, 1.4), pv, skin, 16)
        pv.rotation_euler.y = math.radians(10) * (1 if sx < 0 else -1)
        arms.append(pv)
    if c.get('prop') == 'scroll':
        sc_m = M('parch', L((0.93, 0.86, 0.68)), bump=0.3)
        bpy.ops.mesh.primitive_cylinder_add(vertices=32, radius=0.065, depth=0.42, location=(0.3, -0.07, 0.76)); s_ = bpy.context.object
        s_.rotation_euler = (math.radians(80), math.radians(20), math.radians(-25)); _link(s_, arms[1], sc_m)
        bpy.ops.mesh.primitive_torus_add(major_radius=0.068, minor_radius=0.012, location=(0.3, -0.07, 0.76)); t_ = bpy.context.object
        t_.rotation_euler = (math.radians(80), math.radians(20), math.radians(-25)); _link(t_, arms[1], M('belt', BELT, bump=0.3))
        arms[1].rotation_euler = (math.radians(-40), math.radians(-12), 0)
    root.location = loc; root.rotation_euler.z = rot_z; root.scale = (scale, scale, scale)
    bpy.context.view_layer.update()
    return dict(root=root, body=body, head=head, arms=arms, brows=brows, happy=m_happy, worry=m_worry, eyes=eyes, kind=kind, prop=c.get('prop'))

def animate(d, A, F, t0, t1, frames_per_key=6):
    """Drive a doll from the 2D actor record A: arms, expressions, idle sway, blink, glow, fall."""
    root, body, head = d['root'], d['body'], d['head']
    def set_arms(l, r, f):
        for i, (a, v) in enumerate(zip(d['arms'], (l, r))):
            if d.get('prop') == 'scroll' and i == 1: continue
            a.rotation_euler.y = math.radians(max(10, v * 0.9)) * (1 if i == 0 else -1); a.keyframe_insert('rotation_euler', frame=f)
    prev = None
    for k in A.get('arms') or [[0, 8, 8]]:
        tt = max(t0, k[0])
        if prev: set_arms(*prev, F(tt))
        set_arms(k[1], k[2], F(tt + (0.45 if prev else 0))); prev = (k[1], k[2])
    for e in A.get('expr') or [[0, 'neutral']]:
        tt = max(t0, e[0]); worried = e[1] == 'worried'
        for o, show in ((d['happy'], not worried), (d['worry'], worried)):
            o.hide_render = not show; o.keyframe_insert('hide_render', frame=F(tt))
        for i, b in enumerate(d['brows']):
            b.rotation_euler.y = (-1 if i == 0 else 1) * math.radians(-14 if worried else 0)
            b.keyframe_insert('rotation_euler', frame=F(tt))
    ph = A.get('phase', 0) * 6.28
    t = t0
    while t <= t1 + 0.2:
        body.rotation_euler.z = 0.04 * math.sin(t * 1.3 + ph); body.scale.z = 1 + 0.01 * math.sin(t * 2.2 + ph)
        head.rotation_euler.x = 0.05 * math.sin(t * 0.9 + ph); head.rotation_euler.y = 0.05 * math.sin(t * 0.7 + ph + 1)
        body.keyframe_insert('rotation_euler', frame=F(t)); body.keyframe_insert('scale', frame=F(t)); head.keyframe_insert('rotation_euler', frame=F(t))
        t += frames_per_key / 30
    t = t0 + 1.0 + A.get('phase', 0)
    while t < t1:
        for e in d['eyes']:
            for dt, s in ((0, 1), (0.05, 0.1), (0.13, 1)):
                e.scale.z = s; e.keyframe_insert('scale', frame=F(t + dt))
        t += 3.3
    if A.get('glowk'):
        x, y, z = root.location
        bpy.ops.object.light_add(type='POINT', location=(x, y + 0.9, z + 1.9)); gl = bpy.context.object; gl.data.color = (1, 0.75, 0.4); gl.data.shadow_soft_size = 0.6
        for k in A['glowk']:
            gl.data.energy = 0 if k[1] else 150; gl.data.keyframe_insert('energy', frame=F(max(t0, k[0])))
            gl.data.energy = 150 if k[1] else 0; gl.data.keyframe_insert('energy', frame=F(max(t0, k[0]) + 0.4))
    if A.get('fall'):
        tf = A['fall']; root.keyframe_insert('rotation_euler', frame=F(tf)); root.keyframe_insert('location', frame=F(tf))
        root.rotation_euler.x = math.radians(84); root.location.y += 0.6; root.location.z += 0.3
        root.keyframe_insert('rotation_euler', frame=F(tf + 0.55)); root.keyframe_insert('location', frame=F(tf + 0.55))
