#!/bin/bash
# Re-render the 8 shots that have characters with the 3D felt dolls, then splice into last night's video.
export RANGES=314-798,799-1070,1071-1198,1199-1497,1498-1788,2209-2448,2869-3054,3055-3687
cd /content/temple
mkdir -p /content/out/full
python overlay_full.py > /content/ov.log 2>&1 &
for s in B C C2 D E G2 I J; do python -u full3d.py $s 2>&1 | grep --line-buffered -E "frame|SHOT_DONE|Error|Trace"; done
wait
python -u final_dolls.py
echo RUNDOLLS_DONE
