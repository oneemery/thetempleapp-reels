# Draw the felt actors, text and captions for every frame of Cross Part 3 as transparent PNGs (CPU, runs beside Blender).
import base64, os, subprocess, sys, time
from playwright.sync_api import sync_playwright
HERE = '/content/temple'; OV = '/content/out/ov'; os.makedirs(OV, exist_ok=True)
N = int(sys.argv[1]) if len(sys.argv) > 1 else 4263
srv = subprocess.Popen([sys.executable, '-m', 'http.server', '8766', '--directory', HERE], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
time.sleep(1.5); t0 = time.time()
with sync_playwright() as p:
    b = p.chromium.launch(); pg = b.new_page(viewport={'width': 1080, 'height': 1920})
    pg.goto('http://127.0.0.1:8766/render.html?base=live/cross-part3/&full=1&scale=1')
    pg.wait_for_function('window.ready', timeout=180000); pg.evaluate('window.ready')
    want = None
    if os.environ.get('RANGES'):
        want = set()
        for r in os.environ['RANGES'].split(','):
            a, b = map(int, r.split('-')); want.update(range(a, b + 1))
    for f in range(1, N + 1):
        if want is not None and f not in want: continue
        out = f'{OV}/f{f:04d}.png'
        if os.path.exists(out): continue
        d = pg.evaluate(f'overlayFullAt({(f - 1) / 30})')
        open(out + '.tmp', 'wb').write(base64.b64decode(d.split(',')[1])); os.replace(out + '.tmp', out)
        if f % 300 == 0: print(f'ov {f} {time.time() - t0:.0f}s', flush=True)
    b.close()
srv.terminate(); print('OV_DONE', flush=True)
