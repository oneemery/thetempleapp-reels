# Splice the re-rendered doll shots into last night's finished video. Pass 1: new 3D frames + text overlay through the
# exact same ffmpeg grade as last night. Pass 2: walk both videos frame by frame, taking new frames inside the doll shots.
import os, subprocess
from PIL import Image
OUT = '/content/out'; HERE = '/content/temple'; N = 4263
OLD = '/content/drive/MyDrive/Temple Reels/Temple_Cross_Part3_Full3D.mp4'
RANGES = [tuple(map(int, r.split('-'))) for r in os.environ['RANGES'].split(',')]
new = sorted(set(f for a, b in RANGES for f in range(a, b + 1)))
base = f'{HERE}/live/cross-part3'; voice = [f for f in os.listdir(base) if f.startswith('voice')][0]
graded = f'{OUT}/dolls_graded.mp4'; silent = f'{OUT}/dolls_silent.mp4'; final = f'{OUT}/Temple_Cross_Part3_3D_Dolls.mp4'
enc = subprocess.Popen(['ffmpeg', '-v', 'error', '-y', '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-s', '1080x1920', '-r', '30', '-i', '-',
                        '-vf', 'vignette=angle=0.42,noise=c0s=5:c0f=t+u', '-c:v', 'libx264', '-preset', 'fast', '-crf', '12', '-pix_fmt', 'yuv420p', graded], stdin=subprocess.PIPE)
lastp = None
for i, f in enumerate(new):
    p = f'{OUT}/full/f{f:04d}.jpg'
    if os.path.exists(p): lastp = p
    bg = Image.open(lastp).convert('RGBA'); ov = Image.open(f'{OUT}/ov/f{f:04d}.png').convert('RGBA')
    enc.stdin.write(Image.alpha_composite(bg, ov).convert('RGB').tobytes())
    if i % 600 == 0: print('grade', i, flush=True)
enc.stdin.close(); enc.wait()
FS = 1080 * 1920 * 3
old = subprocess.Popen(['ffmpeg', '-v', 'error', '-i', OLD, '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-'], stdout=subprocess.PIPE)
gn = subprocess.Popen(['ffmpeg', '-v', 'error', '-i', graded, '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-'], stdout=subprocess.PIPE)
out = subprocess.Popen(['ffmpeg', '-v', 'error', '-y', '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-s', '1080x1920', '-r', '30', '-i', '-',
                        '-c:v', 'libx264', '-preset', 'medium', '-crf', '17', '-pix_fmt', 'yuv420p', silent], stdin=subprocess.PIPE)
newset = set(new); last_old = None; last_new = None
for f in range(1, N + 1):
    b = old.stdout.read(FS)
    if len(b) == FS: last_old = b
    if f in newset:
        g = gn.stdout.read(FS)
        if len(g) == FS: last_new = g
        out.stdin.write(last_new)
    else:
        out.stdin.write(last_old)
    if f % 600 == 0: print('splice', f, flush=True)
out.stdin.close(); out.wait(); old.terminate(); gn.terminate()
subprocess.run(['ffmpeg', '-v', 'error', '-y', '-i', silent, '-i', f'{base}/{voice}', '-map', '0:v', '-map', '1:a', '-c:v', 'copy',
                '-c:a', 'aac', '-b:a', '192k', '-shortest', '-movflags', '+faststart', final], check=True)
subprocess.run(['cp', final, '/content/drive/MyDrive/Temple Reels/'], check=True); print('COPIED_TO_DRIVE', flush=True)
print('DOLLS_DONE', flush=True)
