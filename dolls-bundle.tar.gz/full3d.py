# Full Cross Part 3 in 3D: one cinematic shot per section, rendered into /content/out/full/fNNNN.jpg (global frame numbers).
# usage: python full3d.py SHOT        (SHOT in SHOTS below; TEST=1 renders one small still per shot)
import os, sys, math, time, random, json
HERE = os.path.dirname(os.path.abspath(__file__))
SHOT = _MY = sys.argv[1]
_src = open(os.path.join(HERE, 'temple3d.py')).read().split('# ---------------- shots ----------------')[0]
sys.argv = ['x', 'golgotha', 'cycles']
exec(_src)
SHOT = _MY
exec(open(os.path.join(HERE, 'chars3d.py')).read())
import bpy
from mathutils import Vector
TEST = bool(os.environ.get('TEST'))
S = json.load(open(os.path.join(HERE, 'live/cross-part3/scene.json')))
def lab(name, default):
    for e in S['els']:
        if e.get('label') == name: return e['t0']
    return default
T_TURN = lab('IT TURNS', 87.5); T_FIN = lab('IT IS FINISHED', 99.8); T_RES = lab('THE RESURRECTION', 137.9)
T_HH = [e['t0'] for e in S['els'] if e.get('label') == 'HE HATH DONE THIS'][-1:] or [121.1]; T_HH = T_HH[0]
L10, L11, L12 = S['lines'][10][0], S['lines'][11][0], S['lines'][12][0]
TOTAL = 142.08

SHOTS = {  # name: (t0, t1)
    'B': (10.43, 26.61), 'C': (26.61, 35.66), 'C2': (35.66, 39.93), 'D': (39.93, 49.9), 'E': (49.9, 59.6),
    'F': (59.6, 65.6), 'G': (65.6, 73.6), 'G2': (73.6, 81.6), 'H': (81.6, 95.6), 'I': (95.6, 101.8),
    'J': (101.8, 122.9), 'K': (122.9, 128.4), 'L': (128.4, TOTAL)}
T0, T1 = SHOTS[SHOT]
G0 = int(round(T0 * 30)) + 1; G1 = int(round(T1 * 30)) if SHOT != 'L' else int(math.ceil(TOTAL * 30))
LEN = G1 - G0 + 1
def F(t): return max(1, min(LEN, int(round(t * 30)) + 1 - G0 + 1))
sc.frame_start, sc.frame_end = 1, LEN
sc.render.resolution_percentage = int(os.environ.get('TESTRES', 12)) if TEST else 100
sc.cycles.samples = int(os.environ.get('TESTS', 4)) if TEST else 48
sc.cycles.adaptive_threshold = 0.02
sc.cycles.volume_step_rate = 4
sc.view_settings.look = 'AgX - Punchy'
OUTD = os.environ.get('OUTDIR', '/content/out') + '/full'; os.makedirs(OUTD, exist_ok=True)
R = random.Random(sum(map(ord, SHOT)))

_dust0 = dust
def dust(n, box, drift=(0.0, 0.0, 0.25)):
    _dust0(int(n * 0.6), box, drift)
    m = bpy.data.materials.get('dust')
    if m: m.node_tree.nodes['Emission'].inputs['Strength'].default_value = 1.6

# ---------------- palettes (horizon, middle, top) ----------------
DUSK = [(1.0, 0.42, 0.16), (0.55, 0.1, 0.32), (0.025, 0.01, 0.08)]
NIGHT = [(0.13, 0.14, 0.36), (0.05, 0.05, 0.17), (0.008, 0.008, 0.03)]
STORM = [(0.6, 0.14, 0.1), (0.24, 0.04, 0.13), (0.02, 0.005, 0.03)]
COLD = [(0.38, 0.27, 0.5), (0.13, 0.08, 0.24), (0.02, 0.015, 0.05)]
DAWN = [(1.0, 0.8, 0.42), (0.9, 0.45, 0.32), (0.2, 0.13, 0.32)]

def key(sock, pairs, path='default_value'):
    for t, v in pairs:
        sock.default_value = v; sock.keyframe_insert(path, frame=F(t))

def sky2(a, b=None, turn=None, y=70):
    bpy.ops.mesh.primitive_plane_add(size=1, location=(0, y, 40), rotation=(math.radians(90), 0, 0))
    o = bpy.context.object; o.scale = (320, 200, 1); o.visible_shadow = False
    m = bpy.data.materials.new('sky'); m.use_nodes = True; nt = m.node_tree
    for n in list(nt.nodes):
        if n.type != 'OUTPUT_MATERIAL': nt.nodes.remove(n)
    tc = nt.nodes.new('ShaderNodeTexCoord'); sep = nt.nodes.new('ShaderNodeSeparateXYZ'); nt.links.new(tc.outputs['UV'], sep.inputs['Vector'])
    def ramp(c):
        r = nt.nodes.new('ShaderNodeValToRGB'); el = r.color_ramp.elements
        el[0].position = 0.30; el[0].color = (*c[0], 1); el[1].position = 0.48; el[1].color = (*c[2], 1); el.new(0.345).color = (*c[1], 1)
        nt.links.new(sep.outputs['Y'], r.inputs['Fac']); return r
    ra = ramp(a); out = ra.outputs['Color']
    if b:
        rb = ramp(b); mx = nt.nodes.new('ShaderNodeMix'); mx.data_type = 'RGBA'
        nt.links.new(ra.outputs['Color'], mx.inputs['A']); nt.links.new(rb.outputs['Color'], mx.inputs['B'])
        key(mx.inputs['Factor'], [(turn[0], 0.0), (turn[1], 1.0)]); out = mx.outputs['Result']
    e = nt.nodes.new('ShaderNodeEmission'); e.inputs['Strength'].default_value = 1.0
    nt.links.new(out, e.inputs['Color']); nt.links.new(e.outputs['Emission'], nt.nodes['Material Output'].inputs['Surface'])
    o.data.materials.append(m); return o

def focus_at(p):
    f = bpy.data.objects.new('focus', None); sc.collection.objects.link(f); f.location = p; return f

def cam(path, look, lens, fstop, focus):
    return camera([(F(t), p) for t, p in path], [(F(t), p) for t, p in look], lens=lens, fstop=fstop, focus=focus)

def wood_cross(loc=(0, 0, 0.32), s=1.0):
    cr = cross(loc, s)
    for o in cr:
        m = o.data.materials[0]; nt = m.node_tree; b = nt.nodes['Principled BSDF']
        if 'grain' in nt.nodes: continue
        wave = nt.nodes.new('ShaderNodeTexWave'); wave.name = 'grain'; wave.inputs['Scale'].default_value = 2.5; wave.inputs['Distortion'].default_value = 6
        mixc = nt.nodes.new('ShaderNodeMix'); mixc.data_type = 'RGBA'
        mixc.inputs['A'].default_value = (0.045, 0.022, 0.015, 1); mixc.inputs['B'].default_value = (0.11, 0.055, 0.035, 1)
        nt.links.new(wave.outputs['Fac'], mixc.inputs['Factor']); nt.links.new(mixc.outputs['Result'], b.inputs['Base Color'])
    return cr

def scatter(n, arc=(200, 340), rr=(3.5, 12), z=-1.15):
    stone_m = felt('stone', (0.2, 0.15, 0.24), bump=0.6); grass_m = felt('grass', (0.09, 0.12, 0.08), bump=0.3)
    for i in range(n):
        a = R.uniform(math.radians(arc[0]), math.radians(arc[1])); r = R.uniform(*rr)
        x, y = r * math.cos(a), r * math.sin(a)
        if R.random() < 0.45:
            bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=2, radius=R.uniform(0.15, 0.5), location=(x, y, z))
            o = bpy.context.object; o.scale = (1, R.uniform(0.7, 1.2), R.uniform(0.45, 0.8)); bpy.ops.object.shade_smooth(); o.data.materials.append(stone_m)
        else:
            for k in range(R.randint(3, 6)):
                h = R.uniform(0.3, 0.8)
                bpy.ops.mesh.primitive_cone_add(vertices=6, radius1=0.04, depth=h, location=(x + R.uniform(-0.15, 0.15), y + R.uniform(-0.15, 0.15), z - 0.05 + h / 2))
                o = bpy.context.object; o.rotation_euler = (R.uniform(-0.35, 0.35), R.uniform(-0.35, 0.35), 0); o.data.materials.append(grass_m)

def outdoor(pal, pal2=None, turn=None, cross_on=True, hill=True, sun=None, n_stars=220, fog=0.028, village=False, rim=6.0, rim2=None):
    world((0.015, 0.006, 0.03), 1.0, 0)
    sky2(pal, pal2, turn)
    if n_stars: stars(n_stars, 68, 12, 45)
    hz = pal[0]
    if sun:
        m_sun, e_sun = emit('sun', (1.0, 0.72, 0.42), 45)
        bpy.ops.mesh.primitive_uv_sphere_add(radius=6, location=(0, 62, sun[0][1])); so = bpy.context.object; so.data.materials.append(m_sun); so.visible_shadow = False
        for t, z in sun: so.location.z = z; so.keyframe_insert('location', frame=F(t))
    for i, (y, z0, amp, col, seed) in enumerate([(48, 3.0, 4.6, (0.2, 0.08, 0.26), 3), (36, 2.0, 3.6, (0.14, 0.055, 0.21), 5), (24, 0.6, 2.6, (0.1, 0.04, 0.16), 8)]):
        profile_layer(f'range{i}', y, z0, amp, col, seed, width=140)
    if hill:
        bpy.ops.mesh.primitive_uv_sphere_add(segments=128, ring_count=64, location=(0, 0, -2.75)); h = bpy.context.object
        h.scale = (7.5, 7.0, 3.1); bpy.ops.object.transform_apply(scale=True); bpy.ops.object.shade_smooth()
        tex = bpy.data.textures.new('lumps', 'CLOUDS'); tex.noise_scale = 1.6
        dm = h.modifiers.new('lumps', 'DISPLACE'); dm.texture = tex; dm.strength = 0.35
        h.data.materials.append(felt('hill', (0.16, 0.07, 0.22), bump=0.5))
    bpy.ops.mesh.primitive_plane_add(size=120, location=(0, 0, -1.25)); g = bpy.context.object
    gt = bpy.data.textures.new('ground', 'CLOUDS'); gt.noise_scale = 3.0
    sd = g.modifiers.new('sub', 'SUBSURF'); sd.levels = 6; sd.render_levels = 6; sd.subdivision_type = 'SIMPLE'
    gd = g.modifiers.new('g', 'DISPLACE'); gd.texture = gt; gd.strength = 0.5
    g.data.materials.append(felt('ground', (0.07, 0.03, 0.1), bump=0.6))
    cr = wood_cross() if cross_on else None
    scatter(70)
    if village:  # little felt houses with lit windows across the valley
        wm, _ = emit('win', (1.0, 0.7, 0.35), 18); hm = felt('house', (0.22, 0.12, 0.16), bump=0.4); rm = felt('roof', (0.12, 0.05, 0.08), bump=0.4)
        for i in range(46):
            x = R.uniform(-22, 22); y = R.uniform(4, 22); s = R.uniform(0.35, 0.7)
            bpy.ops.mesh.primitive_cube_add(location=(x, y, -1.1 + s)); o = bpy.context.object; o.scale = (s * 1.2, s, s); o.data.materials.append(hm)
            bpy.ops.mesh.primitive_cone_add(vertices=4, radius1=s * 1.5, depth=s * 0.9, location=(x, y, -1.1 + 2 * s + s * 0.45)); r_ = bpy.context.object
            r_.rotation_euler = (0, 0, math.radians(45)); r_.data.materials.append(rm)
            bpy.ops.mesh.primitive_plane_add(size=1, location=(x + R.uniform(-0.3, 0.3) * s, y - s - 0.01, -1.1 + s * R.uniform(0.8, 1.3)), rotation=(math.radians(90), 0, 0))
            w_ = bpy.context.object; w_.scale = (0.28 * s, 0.34 * s, 1); w_.data.materials.append(wm)
    bpy.ops.object.light_add(type='SUN', location=(0, 40, 10)); s_ = bpy.context.object
    s_.data.energy = rim; s_.data.color = hz; s_.data.angle = math.radians(1.2); s_.rotation_euler = (math.radians(-97), 0, math.radians(180))
    if rim2:
        for t, v in rim2: s_.data.energy = v; s_.data.keyframe_insert('energy', frame=F(t))
    bpy.ops.object.light_add(type='AREA', location=(-8, -12, 7)); fl = bpy.context.object
    fl.data.energy = 900; fl.data.color = (0.5, 0.42, 1.0); fl.data.size = 10; fl.rotation_euler = (math.radians(58), 0, math.radians(-32))
    bpy.ops.object.light_add(type='SPOT', location=(2, -5, 7)); kp = bpy.context.object
    kp.data.energy = 900; kp.data.color = (1, 0.75, 0.5); kp.data.spot_size = math.radians(25); kp.data.shadow_soft_size = 1.0
    kp.rotation_euler = (math.radians(38), 0, math.radians(20))
    fb = fog_box(fog); fb.location = (0, 16, 5); fb.scale = (22, 30, 10)
    fb.data.materials[0].node_tree.nodes['Principled Volume'].inputs['Anisotropy'].default_value = 0.8
    dust(260, ((-6, 6), (-10, 6), (-0.8, 7)), drift=(0, 0, 0.18))
    return cr

def bricks(name, c1, c2, mortar, scale=3.0):
    m = felt(name, c1, bump=0.3); nt = m.node_tree; b = nt.nodes['Principled BSDF']
    br = nt.nodes.new('ShaderNodeTexBrick'); br.inputs['Color1'].default_value = (*c1, 1); br.inputs['Color2'].default_value = (*c2, 1)
    br.inputs['Mortar'].default_value = (*mortar, 1); br.inputs['Scale'].default_value = scale; br.inputs['Mortar Size'].default_value = 0.025
    tc = nt.nodes.new('ShaderNodeTexCoord'); nt.links.new(tc.outputs['Object'], br.inputs['Vector'])
    nt.links.new(br.outputs['Color'], b.inputs['Base Color'])
    bp = nt.nodes.new('ShaderNodeBump'); bp.inputs['Strength'].default_value = 0.6; nt.links.new(br.outputs['Fac'], bp.inputs['Height']); nt.links.new(bp.outputs['Normal'], b.inputs['Normal'])
    return m

def box(loc, scale, mat, bevel=0.03):
    bpy.ops.mesh.primitive_cube_add(location=loc); o = bpy.context.object; o.scale = scale
    if bevel: bv = o.modifiers.new('b', 'BEVEL'); bv.width = bevel; bv.segments = 3
    o.data.materials.append(mat); return o

def column(x, y, h, mat, cap, r=0.42):
    bpy.ops.mesh.primitive_cylinder_add(vertices=40, radius=r, depth=h, location=(x, y, h / 2)); c = bpy.context.object; bpy.ops.object.shade_smooth(); c.data.materials.append(mat)
    box((x, y, 0.15), (r + 0.18, r + 0.18, 0.15), mat); box((x, y, h + 0.1), (r + 0.2, r + 0.2, 0.12), cap)

def volume(loc, scale, dens, col=(1, 0.9, 0.8), aniso=0.7):
    f = fog_box(dens); f.location = loc; f.scale = scale
    v = f.data.materials[0].node_tree.nodes['Principled Volume']; v.inputs['Anisotropy'].default_value = aniso; v.inputs['Color'].default_value = (*col, 1)
    return f

def colonnade():
    world((0.012, 0.008, 0.006), 1.0, 0)
    box((0, 8, -0.1), (12, 22, 0.1), felt('floor', (0.2, 0.14, 0.09), bump=0.5, scale=60), bevel=0)
    st = felt('stone', (0.44, 0.33, 0.23), bump=0.5); cap = felt('cap', (0.62, 0.5, 0.36), bump=0.4)
    for side in (-1, 1):
        for i in range(8): column(side * 3.4, -2 + i * 3.4, 7.0, st, cap)
    for i in range(9): box((0, -2 + i * 3.4, 7.45), (4.0, 0.22, 0.22), cap)
    box((0, 10, 8.2), (4.6, 13.5, 0.25), felt('roof', (0.16, 0.11, 0.08), bump=0.4))
    wall = felt('wall', (0.42, 0.31, 0.22), bump=0.5)
    box((-4.6, 25, 4.5), (3.0, 0.5, 4.5), wall); box((4.6, 25, 4.5), (3.0, 0.5, 4.5), wall); box((0, 25, 7.8), (1.7, 0.5, 1.2), wall)
    sky2([(1.0, 0.72, 0.42), (0.85, 0.42, 0.3), (0.3, 0.2, 0.4)], y=40)
    bpy.ops.object.light_add(type='SUN'); s_ = bpy.context.object; s_.data.energy = 9; s_.data.color = (1, 0.72, 0.44); s_.data.angle = math.radians(0.8)
    s_.rotation_euler = (math.radians(53), 0, math.radians(117))
    bpy.ops.object.light_add(type='AREA', location=(0, -10, 4)); fl = bpy.context.object; fl.data.energy = 160; fl.data.color = (0.55, 0.5, 0.9); fl.data.size = 8
    fl.rotation_euler = (math.radians(80), 0, 0)
    volume((0, 10, 4), (9, 17, 4.6), 0.012, (1, 0.92, 0.82), 0.75)
    dust(320, ((-3, 3), (-4, 12), (0.2, 6)), drift=(0, 0, 0.1))
    return focus_at((0, -1.5, 1.2))

def palace(finish=None):
    world((0.01, 0.006, 0.006), 1.0, 0)
    box((0, 4, -0.1), (10, 14, 0.1), felt('pfloor', (0.2, 0.12, 0.08), bump=0.5, scale=60), bevel=0)
    box((0, 3, 0.012), (1.1, 11, 0.012), felt('carpet', (0.5, 0.05, 0.07), bump=0.3, scale=160), bevel=0)
    wall = felt('pwall', (0.2, 0.12, 0.14), bump=0.4); goldm = gold('pgold', 0.6)
    box((0, 14.4, 6), (10, 0.4, 6), wall)
    wm, we = emit('pwin', (1.0, 0.78, 0.45), 4.0)
    for x in (-3.4, 0, 3.4):
        bpy.ops.mesh.primitive_plane_add(size=1, location=(x, 13.95, 5.4), rotation=(math.radians(90), 0, 0)); w_ = bpy.context.object; w_.scale = (1.5, 5.0, 1); w_.data.materials.append(wm)
        bpy.ops.mesh.primitive_cylinder_add(vertices=48, radius=0.75, depth=0.02, location=(x, 13.95, 7.9), rotation=(math.radians(90), 0, 0)); a_ = bpy.context.object; a_.data.materials.append(wm)
        bpy.ops.object.light_add(type='AREA', location=(x, 15.5, 6.2)); al = bpy.context.object; al.data.energy = 900; al.data.color = (1, 0.78, 0.48); al.data.size = 1.6
        al.rotation_euler = (math.radians(-75), 0, 0)
        if finish:
            for t, v in ((finish - 0.3, 900), (finish + 1.6, 3200)): al.data.energy = v; al.data.keyframe_insert('energy', frame=F(t))
    if finish: key(we.inputs['Strength'], [(finish - 0.3, 4.0), (finish + 1.6, 14.0)])
    for x in (-1.7, 1.7):
        box((x, 14.0, 6.2), (0.55, 0.02, 3.6), felt('banner', (0.5, 0.05, 0.08), bump=0.2), bevel=0)
        box((x, 13.96, 2.62), (0.56, 0.02, 0.05), goldm, bevel=0)
    st = felt('pst', (0.3, 0.2, 0.2), bump=0.4)
    for i in range(3): box((0, 10.4 + i * 0.6, 0.15 + i * 0.3), (3.0 - i * 0.5, 0.35, 0.15 + i * 0.3), st)
    box((0, 12.2, 1.4), (0.8, 0.5, 0.5), goldm); box((0, 12.6, 2.6), (0.85, 0.15, 1.5), goldm)
    for side in (-1, 1):
        for i in range(5): column(side * 5.2, -1 + i * 3.2, 9.0, felt('pcol', (0.34, 0.22, 0.22), bump=0.4), goldm, r=0.38)
    fm, _ = emit('flame', (1.0, 0.62, 0.25), 30); cand = felt('cand', (0.85, 0.8, 0.7), bump=0.1)
    for side in (-1, 1):
        for y in (1.0, 4.5, 8.0):
            x = side * 3.6
            bpy.ops.mesh.primitive_cylinder_add(vertices=16, radius=0.05, depth=1.4, location=(x, y, 0.7)); bpy.context.object.data.materials.append(goldm)
            bpy.ops.mesh.primitive_cylinder_add(vertices=16, radius=0.07, depth=0.3, location=(x, y, 1.55)); bpy.context.object.data.materials.append(cand)
            bpy.ops.mesh.primitive_uv_sphere_add(radius=0.05, location=(x, y, 1.78)); fl_ = bpy.context.object; fl_.scale = (1, 1, 1.8); fl_.data.materials.append(fm)
            bpy.ops.object.light_add(type='POINT', location=(x, y, 1.9)); pl = bpy.context.object; pl.data.energy = 25; pl.data.color = (1, 0.62, 0.3); pl.data.shadow_soft_size = 0.1
    bpy.ops.object.light_add(type='AREA', location=(0, -9, 4)); fl = bpy.context.object; fl.data.energy = 350; fl.data.color = (0.55, 0.45, 0.9); fl.data.size = 8
    fl.rotation_euler = (math.radians(78), 0, 0)
    volume((0, 6, 4.5), (6, 9, 4.5), 0.022, (1, 0.9, 0.8))
    dust(260, ((-3, 3), (-3, 12), (0.2, 6)), drift=(0, 0, 0.08))
    return focus_at((0, -3, 1.2))

def walls_set():
    world((0.004, 0.006, 0.014), 1.0, 0)
    box((0, 6, -0.1), (16, 20, 0.1), felt('wfloor', (0.06, 0.045, 0.1), bump=0.5, scale=60), bevel=0)
    bm = bricks('brick', (46 / 255 * 0.55, 28 / 255 * 0.55, 66 / 255 * 0.55), (40 / 255 * 0.5, 24 / 255 * 0.5, 58 / 255 * 0.5), (0.03, 0.018, 0.045), scale=2.2)
    lw = box((-9, 4, 4), (2.0, 9, 4.5), bm); rw = box((9, 4, 4), (2.0, 9, 4.5), bm)
    def ease_(x): x = max(0, min(1, x)); return x * x * (3 - 2 * x)
    for f in range(1, LEN + 1, 3):
        t = (G0 + f - 2) / 30
        p = ease_((t - L11) / 2.2) if t > L11 else 0; q = 0.25 * ease_((t - L10) / 2.0)
        inner = 6.6 - (q + 0.6 * p) * 6.2
        lw.location.x = -(inner + 2.0); rw.location.x = inner + 2.0
        lw.keyframe_insert('location', frame=f); rw.keyframe_insert('location', frame=f)
    gm, ge = emit('heaven', (0.22, 0.28, 0.62), 0.9)
    bpy.ops.mesh.primitive_plane_add(size=1, location=(0, 22, 6), rotation=(math.radians(90), 0, 0)); hv = bpy.context.object; hv.scale = (30, 18, 1); hv.data.materials.append(gm)
    key(ge.inputs['Strength'], [(L12 - 0.2, 0.9), (L12 + 1.8, 0.02)])
    bpy.ops.object.light_add(type='SPOT', location=(0, -0.5, 9)); sp = bpy.context.object; sp.data.energy = 2600; sp.data.color = (0.7, 0.78, 1.0)
    sp.data.spot_size = math.radians(34); sp.data.spot_blend = 0.4; sp.data.shadow_soft_size = 0.3
    bpy.ops.object.light_add(type='AREA', location=(0, -12, 3)); fl = bpy.context.object; fl.data.energy = 220; fl.data.color = (0.5, 0.45, 0.85); fl.data.size = 6
    fl.rotation_euler = (math.radians(82), 0, 0)
    volume((0, 6, 4.5), (8, 14, 5), 0.03, (0.9, 0.92, 1.0), 0.6)
    dust(200, ((-3, 3), (-4, 8), (0.2, 6)), drift=(0, 0, -0.05))
    return focus_at((0, -2, 1.2))

def temple():
    world((0.012, 0.008, 0.006), 1.0, 0)
    box((0, 4, -0.1), (14, 16, 0.1), felt('tfloor', (0.2, 0.14, 0.12), bump=0.5, scale=60), bevel=0)
    stn = felt('tstone', (0.5, 0.38, 0.27), bump=0.5); cap = gold('tgold', 0.5)
    for i in range(5): box((0, 5.4 + i * 0.5, 0.12 + i * 0.24), (5.5, 0.3 + (4 - i) * 0.02, 0.12 + i * 0.24), stn)
    box((-4.0, 9.5, 5), (2.6, 0.6, 5), stn); box((4.0, 9.5, 5), (2.6, 0.6, 5), stn); box((0, 9.5, 8.6), (1.5, 0.6, 1.4), stn)
    bpy.ops.mesh.primitive_cone_add(vertices=3, radius1=8.6, depth=1.2, location=(0, 8.9, 11.6), rotation=(math.radians(90), 0, 0)); pd = bpy.context.object
    pd.scale = (1, 0.32, 1); pd.data.materials.append(stn)
    for x in (-5.4, -2.6, 2.6, 5.4): column(x, 7.6, 9.8, stn, cap, r=0.45)
    dm, de = emit('door', (1.0, 0.86, 0.58), 9.0)
    bpy.ops.mesh.primitive_plane_add(size=1, location=(0, 10.15, 3.6), rotation=(math.radians(90), 0, 0)); d_ = bpy.context.object; d_.scale = (3.0, 7.2, 1); d_.data.materials.append(dm)
    bpy.ops.object.light_add(type='AREA', location=(0, 9.9, 3.4)); al = bpy.context.object; al.data.energy = 4200; al.data.color = (1, 0.82, 0.55); al.data.size = 2.8
    al.rotation_euler = (math.radians(90), 0, 0)
    bpy.ops.object.light_add(type='AREA', location=(0, -10, 5)); fl = bpy.context.object; fl.data.energy = 300; fl.data.color = (0.5, 0.45, 0.9); fl.data.size = 8
    fl.rotation_euler = (math.radians(75), 0, 0)
    sky2(NIGHT, y=40); stars(140, 38, 8, 30)
    volume((0, 3, 4), (9, 8, 5), 0.02, (1, 0.92, 0.82))
    dust(300, ((-3, 3), (-4, 9), (0.2, 6)), drift=(0, 0, 0.12))
    return d_


# ---------------- felt dolls in the sets ----------------
def ground_z(x, y):
    bpy.context.view_layer.update(); dg = bpy.context.evaluated_depsgraph_get(); z = 3.0
    for _ in range(40):
        hit, loc, nrm, idx, ob, mx = sc.ray_cast(dg, Vector((x, y, z)), Vector((0, 0, -1)))
        if not hit: return 0.0
        n = ob.name.lower()
        if n.startswith(('fog', 'sky', 'star', 'dust', 'ico', 'sun', 'focus')) or ob.type != 'MESH' or ob.display_type == 'WIRE': z = loc.z - 0.01; continue
        mats = [m.name.lower() for m in ob.data.materials if m]
        if any(m.startswith(('fog', 'dust', 'star', 'sky', 'sun', 'heaven', 'win', 'door')) for m in mats): z = loc.z - 0.01; continue
        return loc.z
    return 0.0

def place(kind, A, x, y, rot=0.0, scale=1.0, robe=None, name=None, z=None, appear=None):
    zz = ground_z(x, y) if z is None else z
    d = doll(kind, (x, y, zz), rot_z=rot, scale=scale, robe=robe, name=name, seed=int(abs(x) * 100 + abs(y) * 10))
    a0 = max(T0, A.get('t0', T0)); a1 = min(T1, A.get('t1', T1))
    animate(d, A, F, a0, a1)
    r = d['root']
    if appear is not None:  # pop in like the 2D element did
        for tt, sv in ((appear - 0.02, 0.0), (appear, 0.0), (appear + 0.16, scale * 1.08), (appear + 0.26, scale)):
            r.scale = (sv, sv, sv); r.keyframe_insert('scale', frame=F(max(T0, tt)))
    else:
        keys = [(a0, scale), (a1, scale)]
        if a0 > T0 + 0.1: keys = [(a0 - 0.05, 0.0)] + keys
        if a1 < T1 - 0.1: keys = keys + [(a1 + 0.05, 0.0)]
        for tt, sv in keys: r.scale = (sv, sv, sv); r.keyframe_insert('scale', frame=F(tt))
    return d

ACT = S['actors']
def crowd_row(t_list, y, xs, glow=False):
    ds = []
    for i, (x, t) in enumerate(zip(xs, t_list)):
        ds.append(place('p2', {'arms': [[0, 14, 14]], 'expr': [[0, 'happy']], 'phase': i * 0.137, 'glowk': [[0, True]] if glow else None}, x, y,
                        rot=math.radians(-x * 3), scale=0.92, robe=CROWD[i % len(CROWD)], name=f'crowd{i}', appear=t))
    return ds

# ---------------- the shots ----------------
if SHOT == 'B':
    fo = colonnade()
    d = place('paul', ACT[0], -0.95, -1.4, rot=math.radians(18)); fo = d['head']
    cam([(T0, (-1.6, -7.2, 1.7)), (T1, (0.9, -6.3, 2.0))], [(T0, (-0.4, 8, 2.5)), (T1, (0.5, 8, 2.7))], 30, 2.2, fo)
elif SHOT in ('C', 'I'):
    fo = palace(T_FIN if SHOT == 'I' else None)
    d = place('dking', ACT[1] if SHOT == 'C' else ACT[3], 0, -2.6); fo = d['head']
    if SHOT == 'C': cam([(T0, (0, -9.4, 1.6)), (T1, (0, -7.4, 1.75))], [(T0, (0, 10, 2.4)), (T1, (0, 10, 2.55))], 32, 2.0, fo)
    else: cam([(T0, (-1.2, -8.4, 1.35)), (T1, (0.4, -6.9, 1.6))], [(T0, (0, 10, 2.6)), (T1, (0, 10, 3.0))], 30, 2.0, fo)
elif SHOT == 'C2':
    outdoor(DUSK, cross_on=False, hill=False, village=True, fog=0.022)
    crowd_row([e['t0'] for e in S['els'] if e.get('label') == 'crowd person (glow)'], -2.5, [-3.3, -2.2, -1.1, 0, 1.1, 2.2, 3.3], glow=True)
    cam([(T0, (0, -13, 1.0)), (T1, (0, -12, 3.4))], [(T0, (0, 12, 0.6)), (T1, (0, 12, 1.0))], 28, 3.2, focus_at((0, -6, 0)))
elif SHOT == 'D':
    cr = outdoor(DUSK)
    crowd_row([e['t0'] for e in S['els'] if e.get('label') == 'crowd person'], -4.6, [-2.85, -1.9, -0.95, 0, 0.95, 1.9, 2.85])
    cam([(T0, (0, -17, 1.0)), (T1, (0.4, -11.5, 1.7))], [(T0, (0, 0, 2.6)), (T1, (0, 0, 3.0))], 34, 2.0, cr[0])
elif SHOT == 'F':
    cr = outdoor(STORM, fog=0.036, n_stars=60, rim=9.0)
    cam([(T0, (1.4, -5.6, -0.7)), (T1, (0.3, -4.9, 0.5))], [(T0, (0, 0, 1.2)), (T1, (0, 0, 3.9))], 20, 2.0, cr[0])
elif SHOT == 'G':
    outdoor(NIGHT, rim=3.0)
    cam([(T0, (-3.2, -19, 2.0)), (T1, (3.2, -18, 2.5))], [(T0, (0, 0, 2.4)), (T1, (0, 0, 2.6))], 50, 1.4, focus_at((0, -12, 1.0)))
elif SHOT == 'G2':
    outdoor(COLD, rim=4.0)
    d = place('jesse', ACT[2], 0, -3.4)
    cam([(T0, (0, -10.5, 0.8)), (T1, (0.2, -9.3, 1.0))], [(T0, (0, 0, 1.4)), (T1, (0, 0, 1.6))], 40, 1.8, focus_at((0, -5.5, 0)))
elif SHOT == 'H':
    outdoor(NIGHT, DAWN, (T_TURN - 0.5, T_TURN + 4.5), sun=[(T_TURN - 1, -5.0), (T1, 3.5)], rim=3.0, rim2=[(T_TURN - 0.5, 3.0), (T_TURN + 4.5, 9.0)])
    cam([(T0, (0, -14.5, 0.4)), (T1, (0, -12.0, 3.0))], [(T0, (0, 20, 2.0)), (T1, (0, 20, 4.2))], 30, 2.8, focus_at((0, 0, 2)))
elif SHOT == 'J':
    outdoor(NIGHT, DAWN, (T_HH - 0.6, T1), cross_on=False, rim=2.5, rim2=[(T_HH - 0.6, 2.5), (T1, 8.0)])
    d = place('p3', ACT[4], 0, -6.6)
    bpy.ops.object.light_add(type='POINT', location=(2.6, -6.2, -0.55)); lp = bpy.context.object; lp.data.energy = 140; lp.data.color = (1, 0.6, 0.28); lp.data.shadow_soft_size = 0.2
    lm, _ = emit('lantern', (1, 0.62, 0.3), 25); bpy.ops.mesh.primitive_uv_sphere_add(radius=0.06, location=(2.6, -6.2, -0.72)); bpy.context.object.data.materials.append(lm)
    cam([(T0, (-1.8, -12.2, 0.3)), (T1, (1.8, -11.4, 0.7))], [(T0, (0, 0, 1.2)), (T1, (0, 0, 1.5))], 36, 1.8, focus_at((0, -6.5, 0)))
elif SHOT == 'E':
    fo = walls_set()
    _im = [e for e in S['els'] if e.get('label') == 'image'][0]
    d = place('p2', {'t0': _im['t0'], 't1': _im['t1'], 'arms': [[0, 10, 10]], 'expr': [[0, 'worried']], 'phase': 0.3}, 0, -1.3, appear=_im['t0']); fo = d['head']
    cam([(T0, (0, -12.5, 1.6)), (T1, (0, -9.4, 1.45))], [(T0, (0, 4, 1.7)), (T1, (0, 4, 1.6))], 32, 2.6, fo)
elif SHOT == 'K':
    door = temple()
    cam([(T0, (0, -10.5, 1.1)), (T1, (0, -6.8, 2.0))], [(T0, (0, 10, 3.4)), (T1, (0, 10, 3.6))], 28, 2.8, door)
elif SHOT == 'L':
    cr = outdoor(DUSK, DAWN, (T_RES - 1.0, T_RES + 2.5), sun=[(T_RES - 2.5, -4.0), (T1, 5.5)], rim2=[(T_RES - 1.0, 6.0), (T_RES + 2.5, 14.0)])
    cam([(T0, (0, -9.0, 0.8)), (T1, (0, -13.5, 2.3))], [(T0, (0, 0, 3.0)), (T1, (0, 0, 3.7))], 30, 2.0, cr[0])

t0 = time.time(); n = 0
_tt = F(float(os.environ.get('TT', (T0 + T1) / 2)))
frames = list(range(_tt, min(LEN, _tt + int(os.environ.get('NF', 1)) - 1) + 1)) if TEST else range(1, LEN + 1)
if os.environ.get('PERSIST', '1') == '1': sc.render.use_persistent_data = True
for f in frames:
    g = G0 + f - 1
    path = f'{OUTD}/{SHOT}_test{f}.jpg' if TEST else f'{OUTD}/f{g:04d}.jpg'
    _t1 = time.time()
    if not TEST and os.path.exists(path) and os.path.getsize(path) > 10000: continue
    sc.frame_set(f); sc.render.filepath = path
    bpy.ops.render.render(write_still=True); n += 1
    if TEST: print(f'FRAME {f} {time.time() - _t1:.2f}s', flush=True)
    if n % 30 == 1: print(f'{SHOT} frame {g} ({f}/{LEN}) {time.time() - t0:.0f}s', flush=True)
print(f'SHOT_DONE {SHOT} {n} frames {round((time.time() - t0) / max(1, n), 2)} s/frame', flush=True)
