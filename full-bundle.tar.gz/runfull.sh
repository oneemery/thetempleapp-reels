#!/bin/bash
# Full Cross Part 3 in 3D: hero frames + 13 cinematic shots + overlay + grade. Resumable: rerun skips finished frames.
cd /content/temple
mkdir -p /content/out/full
for f in $(seq 1 313); do n=$(printf %04d $f); [ -f /content/out/hero/f$n.jpg ] && cp -n /content/out/hero/f$n.jpg /content/out/full/f$n.jpg; done
python overlay_full.py > /content/ov.log 2>&1 &
for s in B C C2 D E F G G2 H I J K L; do python full3d.py $s 2>&1 | grep -E "frame|SHOT_DONE|Error|Trace"; done
wait
python final_full.py
echo RUNFULL_DONE
