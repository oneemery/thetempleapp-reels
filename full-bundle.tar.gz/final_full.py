# Composite the 3D frames + overlay PNGs, add a film grade (grain, vignette), mux the voice, copy to Drive.
import os, subprocess
from PIL import Image
HERE = '/content/temple'; OUT = '/content/out'; N = 4263
base = f'{HERE}/live/cross-part3'; voice = [f for f in os.listdir(base) if f.startswith('voice')][0]
silent = f'{OUT}/full_silent.mp4'; final = f'{OUT}/Temple_Cross_Part3_Full3D.mp4'
ff = subprocess.Popen(['ffmpeg', '-v', 'error', '-y', '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-s', '1080x1920', '-r', '30', '-i', '-',
                       '-vf', f'vignette=angle=0.42,noise=c0s=5:c0f=t+u,fade=t=out:st={N / 30 - 0.7:.2f}:d=0.7',
                       '-c:v', 'libx264', '-preset', 'medium', '-crf', '17', '-pix_fmt', 'yuv420p', silent], stdin=subprocess.PIPE)
last = None; missing = 0
for f in range(1, N + 1):
    p = f'{OUT}/full/f{f:04d}.jpg'
    if os.path.exists(p): last = p
    else: missing += 1
    bg = Image.open(last).convert('RGB')
    if bg.size != (1080, 1920): bg = bg.resize((1080, 1920), Image.LANCZOS)
    ov = Image.open(f'{OUT}/ov/f{f:04d}.png').convert('RGBA')
    ff.stdin.write(Image.alpha_composite(bg.convert('RGBA'), ov).convert('RGB').tobytes())
    if f % 600 == 0: print('final', f, flush=True)
ff.stdin.close(); ff.wait()
subprocess.run(['ffmpeg', '-v', 'error', '-y', '-i', silent, '-i', f'{base}/{voice}', '-map', '0:v', '-map', '1:a', '-c:v', 'copy',
                '-c:a', 'aac', '-b:a', '192k', '-shortest', '-movflags', '+faststart', final], check=True)
print('missing frames', missing, flush=True)
if os.path.isdir('/content/drive/MyDrive'):
    os.makedirs('/content/drive/MyDrive/Temple Reels', exist_ok=True)
    subprocess.run(['cp', final, '/content/drive/MyDrive/Temple Reels/'], check=True); print('COPIED_TO_DRIVE', flush=True)
print('FULL_DONE', flush=True)
